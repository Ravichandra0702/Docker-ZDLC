# UpShift-ZDLC

Steps to Run UpShift-ZDLC -

1. Unzip UpShift-Zdlc.zip. This unpacks to below shown structure - 
			
		    -- package-final-output
			 | - conf/
			 | - db/
			 | - lib/
			 | - start.bat
			 | - start.sh 
			 | - start_database.sh 
			 | - server.properties
			 | - PluginManifest.yml

2. For Unix/OSx systems, provide execute permission by running 'chmod a+x *.sh' command, and run start.sh by typing ./start.sh in commandline.

3. For Windows operating system, either double click start.bat or execute the batch file from command prompt.

4. Starting Zdlc will open a command window - DO NOT CLOSE THE WINDOW.

5. For Zdlc to run, following ports are required - 
	* 8080 for accessing zdlc ui.
	* 9001 for hsql db.
	
6. After starting Zdlc application, ZDLC UI can be accessed at http://localhost:8080/zdlc

7. If the Product Key is not available/expired, a pop up will be displayed to input the product key. Here you can use the product key received 
	over the mail.

-------------------------------------------------------------------------------------------------------------------------------
Running UpShift-ZDLC as a blueprint from the UpShift Platform

- This needs to be done, only when the UpShift-ZDLC is registered as plugin via "Add URL" option.

1. Copy the API Key from the plugins page in the Platform.

2. Login in to UpShift-ZDLC as an admin User.

3. Click on configuration tab, and paste the UpShift API Key, UpShift URL and save the details.

4. Now the blueprint can be started in UpShift.

