#!/bin/bash

export CLASSPATH; CLASSPATH=db/lib/hsqldb.jar

java org.hsqldb.server.Server org.hsqldb.server.Server -database.0 file:db/data/zdlc_file;ifexists=true &