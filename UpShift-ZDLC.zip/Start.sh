#!/bin/bash
rm -f console.out
rm -f zdlc_server.out

./start_database.sh &

sleep 5

echo "ZDLC Database started...."

SERVER_PORT=$1

if [ "$SERVER_PORT" = "" ]
then
	SERVER_PORT=8080
fi

echo "Running on port " $SERVER_PORT
	
eval java -Dserver.port=$SERVER_PORT -Dehcache.disk.store.dir=conf/ZDLC_Cache -Dzdlc.log=conf/ZDLC_log4j_conf.xml -Djava.naming.factory.initial=org.apache.naming.java.javaURLContextFactory -Xms256m -Xmx1024m -jar lib/upshift-zdlc.jar >> console.out 2>zdlc_server.out &

sleep 30

echo "ZDLC Server started...."